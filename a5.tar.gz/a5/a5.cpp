#include <cmath>
#include <cstdio>
#include<string.h>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

struct node {
node *left=NULL;
node *right=NULL;
node *parent=NULL;
    int l;
}; 
 
int d=0;

void rec( struct node *head,int l)
{
    if(head->left!=NULL)
    {
        if(d<(l+1))
            d=l+1;
        head->left->l=l+1;
        rec(head->left,l+1);
    }
    // for(int i=0;i<(d-l);i++)
    //     cout<<" ";
    // cout<<"*"<<endl;
    
    if(head->right!=NULL)
    {
        if(d<(l+1))
            d=l+1;
        head->right->l=l+1;
        rec(head->right,l+1);
    }
}

void print( struct node *head)
{
    if(head!=NULL){
    print(head->left);
    for(int i=0;i<(d-head->l);i++)
        cout<<" ";
    cout<<"*"<<endl;
    print(head->right);}
}

int main() 
{
    int s;
    cin>>s;
    char arr[10000000];
    
    cin>>arr;
    
    struct node *head=new struct node;
    struct node *curnt;
    curnt=head;
    
    int l=strlen(arr);
    
    for(int i=0;i<l;i++)
    {
        if(arr[i]=='0')
        {
             struct node  *temp=new struct node;
             temp->parent=curnt;
             curnt->left=temp;
             curnt=temp;
         
        }
        if(arr[i]=='2')
        {
            struct node  *temp=new struct node;
            temp->parent=curnt;
            curnt->right=temp;
            curnt=temp;
           
        }
        if(arr[i]=='1')
        {
            curnt=curnt->parent;
        }
    }
    
    if(s==1)
    {
        curnt=head;

        for(int i=0;i<l;i++)
        {
            if(curnt->left!=NULL)
            {
                cout<<"0";
                curnt=curnt->left;
            }
            else if(curnt->right!=NULL)
            {
                cout<<"1";
                curnt=curnt->right;
            }
            else if(curnt->right==NULL && curnt->right==NULL)
            {
                if(curnt->parent->left==curnt)
                {
                    cout<<"0";

                    curnt=curnt->parent;
                    curnt->left=NULL;
                }
                else
                {
                    cout<<"1";

                    curnt=curnt->parent;
                    curnt->right=NULL;
                }
            }
        }
    }
    
    else if(s==2)
    {   
        
        
            struct node *headd=new struct node;
            struct node *curntt;
            curntt=headd;
                        for(int i=0;i<l;i++)
                    {
                        if(arr[i]=='0')
                        {
                             struct node  *temp=new struct node;
                             temp->parent=curntt;
                             curntt->left=temp;
                             curntt=temp;

                        }
                        if(arr[i]=='2')
                        {
                            struct node  *temp=new struct node;
                            temp->parent=curntt;
                            curntt->right=temp;
                            curntt=temp;

                        }
                        if(arr[i]=='1')
                        {
                            curntt=curntt->parent;
                        }
                    }

                
                        curntt=headd;

                        for(int i=0;i<l;i++)
                        {
                            if(curntt->left!=NULL)
                            {
                                cout<<"0";
                                curntt=curntt->left;
                            }
                            else if(curntt->right!=NULL)
                            {
                                cout<<"1";
                                curntt=curntt->right;
                            }
                            else if(curntt->right==NULL && curntt->right==NULL)
                            {
                                if(curntt->parent->left==curntt)
                                {
                                    cout<<"0";

                                    curntt=curntt->parent;
                                    curntt->left=NULL;
                                }
                                else
                                {
                                    cout<<"1";

                                    curntt=curntt->parent;
                                    curntt->right=NULL;
                                }
                            }
                        }
    cout<<endl;
        head->l=0;
        curnt=head;
        rec(curnt,0);
        print(head);
    }
    
    return 0;
}
