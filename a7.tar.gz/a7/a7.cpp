/*****************
File Name : CS18M063_HW7.cpp
Assignment:  APL-Assignment HW 7
Author: Ankur Yadav(CS18M063)
Date: 15 Sep 2018
Description: File is using Breadth First Search.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
int m,n;   // m- no of vertices && n- no of edges 

struct node // for adjacency list
{
    int val;
    struct node *next;
};

int bfs(struct node **arr,int *B,int x)  //find the hop count
{
    int queue[m];
    int val[m];
    int front=0,rear=0;

    for(int i=0;i<x;i++)
    {
        val[i]=0;
        queue[rear++]=B[i];
    }
    struct node *t;
    
    while(front<rear)
    {
        t=arr[queue[front]];
        while(t!=NULL)
        {
            int temp=0;
            for(int i=0;i<rear;i++)
            {
                if(t->val==queue[i])
                    temp=1;
            }
            if(temp==0)
            {
                queue[rear]=t->val;
                val[rear++]=val[front]+1;
            }
            t=t->next;
        }
        front++;
    }
        return (val[rear-1]+1); // return hop count
}

void reach(struct node **arr) // to find the minimal set
{    
    int final[m][m];
    
    for(int i=0;i<m;i++) // initialize with -1
    for(int j=0;j<m;j++)
    final[i][j]=-1;
    
    for(int i=0;i<m;i++)     // make the matrix in which explore all reachability of each vertices if not reachable than -1
    {
        final[i][i]=i;
        int queue[m];
        int front=0,rear=0;
        
        struct node *t=arr[i];
        while(t!=NULL) 
        {
            queue[rear++]=t->val;
            final[i][t->val]=t->val;
            t=t->next;
        }
        
        while(front<rear) // implementing bfs to find the reachability of each node
        {
            t=arr[queue[front]];
            while(t!=NULL)
            {
                if(final[i][t->val]==-1)
                {
                    queue[rear++]=t->val;
                    final[i][t->val]=t->val;
                }
                t=t->next;
            }
            front++;
        }
    }

    int A[m];
    
    for(int i=0;i<m;i++) // to find the set 
        A[i]=i;
    
    for(int i=0;i<m;i++)  // to find the minimal set if we find vertices that is head of minimal set make all reachable entry in array -1
    {
        if(A[i]!=-1)
        for(int j=0;j<m;j++)
        {
            if(A[j]!=-1)
            {
                int temp=0;
                if(j!=i)
                {
                for(int k=0;k<m;k++)
                {
                    if(final[i][k]-final[j][k]==0 || final[j][k]==-1)
                        temp=1;
                    else
                    {
                        temp=2;
                        k=m;
                    }
                }
                if(temp==1)
                    A[j]=-1;
                }
            }
        }
    }
    int B[m],size=0;
    for(int i=0;i<m;i++) // print the minimal set
    {
        if(A[i]!=-1)
        {
            B[size++]=A[i];
            cout<<i<<" ";
        }
        
    }
    cout<<endl<<bfs(arr,B,size); // put all minimal set in an array and find the hop count
}

int main() 
{
    cin>>m>>n;
    int i,j;  // for an eedge
    struct node *arr[m]={NULL}; // array of structure (vertices)
    
    while(cin>>i && cin>>j)
    {
        
        node *temp=new node;
        temp->val=j;
        temp->next=NULL;
        
        if(arr[i]==NULL) // insert first edge corresponding to each vertex
        {
            arr[i]=temp;
        }
        else // insert edge at last position
        {
            struct node *t=arr[i];
            while(t->next!=NULL)
            {
                t=t->next;
            }
            t->next=temp;
        }
    }
    if(n==0) // if no edge
    {
        for(i=0;i<m;i++)
        {
            cout<<i<<" ";
        }
        cout<<endl<<"1";
    }
    else
        reach(arr); // find the minimal set
    return 0;
}

