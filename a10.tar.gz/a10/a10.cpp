/*****************
File Name : CS18M063_hw4.cpp
Assignment:  APL-Assignment HW 4
Author: Ankur Yadav(CS18M063)
Date: 26 Aug 2018
Description: File is using merge sort.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
struct node
{
    long value1; // for x coordinate
    long value2; // for y coordinate
    int rank=0;  // for rank
    int pos;     // for index
};

void merge(struct node A[],int l,int m,int r,int sort) //merging of element
{ 
    int i, j, k; 
    int n1=m-l+1; // size of first array of structure (left)
    int n2=r-m;   // size of second array of structure (right)
  
    struct node L[n1],R[n2]; // declaration of structure
     
    for(i=0;i<n1;i++)    // storing the element
        L[i]=A[l+i]; 
    for(j=0;j<n2;j++) 
        R[j]=A[m+1+j]; 
  
    i=0;    
    j=0;  
    k=l;  
    if(sort==1)    // sorting of x coordinate
    {
        while (i<n1 && j<n2) 
        { 
            if (L[i].value1 < R[j].value1) 
            { 
                A[k]=L[i]; 
                i++; 
            } 
            else if(L[i].value1==R[j].value1)
            {
                if(L[i].value2>R[j].value2)
                {
                    A[k]=L[i];
                    i++;
                }
                else
                { 
                    A[k]=R[j];  
                    j++; 
                } 
            }
            else
            { 
                A[k]=R[j]; 
                j++; 
            } 

            k++; 
        } 
    }
    else if(sort==2)  // sorting of y coordinate
    {
        while(i<n1 && j<n2) 
        { 
            if(L[i].value2 < R[j].value2) 
            { 
                A[k]=L[i]; 
                i++; 
            } 
            else
            { 
                A[k]=R[j]; 
                j++; 
            } 
            k++; 
        } 
    }
        
    while(i<n1)   // storing the element after sorting
    { 
        A[k]=L[i]; 
        i++; 
        k++; 
    } 
  
    while(j<n2) 
    { 
        A[k]=R[j]; 
        j++; 
        k++; 
    } 
} 
  
void merging(struct node A[],int l,int r,int sort)   // merge sort last argument 1 for x coordinate & 2 for y coordinate
{ 
    if(l<r) 
    { 
        int m=l+(r-l)/2; 
  
        merging(A,l,m,sort); //divide
        merging(A,m+1,r,sort); 
  
        merge(A,l,m,r,sort); //merge
    } 
} 
void rank_merge(struct node A[],int l,int m, int r)  
{
    
    int c=0,i,j;
     merging(A, l, m,2);   // sort the y coordinate using merge sort in and last argument 2 for y coordinate 
     merging(A, m+1,r,2);   
    
    for(j=l,i=m+1;j<=m && i<=r;)  // to know the rank
    {
        {
            if(A[i].value2>A[j].value2)  
            {
                c++;
                j++;
            }
            else 
            {
                A[i].rank+=c;
                i++;    
            }
        }    
    }
    for(;i<=r;i++)
    A[i].rank+=c;    
}

void ranking(struct node A[], int l, int r)     // rank sort like as merge sort
{ 
    if (l < r) 
    { 
        int m = l+(r-l)/2; 
  
        ranking(A, l, m);  // divide in two part
        ranking(A, m+1, r); 
  
        rank_merge(A, l, m, r); // merging of two part
    } 
}

int main() 
{
    int p;
    cin>>p;   // no of test cases
    while(p--)
    {
        int n;
        cin>>n;  // no of coordinate
        
        struct node A[n];
        
        for(int i=0;i<n;i++)
        {
            cin>>A[i].value1;  // x coordinate
            cin>>A[i].value2;  // y coordinate
            A[i].pos=i;        // storing the position
        }
        merging(A, 0, n- 1,1);  // merge sort function call & last argument  1 for x coordinate
        
        ranking(A,0,n-1);     // rank sort function call
        int b[n];  // array to store rank

        for(int i=0;i<n;i++)
        {
            b[A[i].pos]=A[i].rank;  // to know the rank
        }
       
        for(int i=0;i<n;i++)
        {
            cout<<b[i]<<" ";
        }
       
        cout<<"\n";
    }
    return 0;
}
