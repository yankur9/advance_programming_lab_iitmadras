/*****************
File Name : CS18M063_HW10.cpp
Assignment:  APL-Assignment HW-10
Author: Ankur Yadav(CS18M063)
Date: 19 Oct 2018
Description: File is using subset sum bottom up approach of dynamic programming.
*****************/
#include <iostream>
/* DO NOT USE STL */

using namespace std;

bool isSubsetSum(int set[], int n, int sum,int temp) // check the appropriate subset sum and print the result
{
    bool subset[n+1][sum+1];
    
        for (int i = 1; i <= sum; i++) 
          subset[0][i] = false; 

        for (int i = 0; i <= n; i++) 
          subset[i][0] = true; 

         for (int i = 1; i <= n; i++) 
         { 
           for (int j = 1; j <= sum; j++) 
           { 
             if(j<set[i-1]) 
             subset[i][j] = subset[i-1][j]; 
             if (j >= set[i-1]) 
               subset[i][j] = subset[i-1][j] ||  subset[i - 1][j-set[i-1]]; 
           } 
         } 
    if(temp==1) // IF SUBSET SUM IS APPROPRIATE
    {
        while(sum>0)
        {
            for(int i=0;i<=n;)
            {
                if(subset[i][sum]==0)
                    i++;
                else
                {
                    cout<<i-1<<" "; //print the index
                    sum-=set[i-1];  // substract the index value
                    i=n+1;
                }
            }
        }
    }
 
     return subset[n][sum]; 
} 

int main() 
{
    int n;
    cin>>n;    // size of input array
    
    int *A=new int[n];
    int sum=0;
    for(int i=0;i<n;i++) // input array and sum
    {
        cin>>A[i];
        sum+=A[i];
    }
    
    sum=(sum*40/100);    // calculate the sum 40%   
    
    while(isSubsetSum(A,n,sum,0)==0)   // find the appropriate subset sum
    {
        sum--;
    }
   isSubsetSum(A,n,sum,1); // print the result of appropriate sum
    return 0;
}
