/*****************
File Name : CS18M063_JumpingKangaroo2.cpp
Assignment:  Advance Programming Lab HW - 1 
Author: Ankur Yadav(CS18M063)
Date: 04 Aug 2018
Description: File implement iteration using array of three variable(constant space).
*****************/

#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    long long int temp,query;          //query for number of query, temp is temporary variable
    cin>>query;
    
    while(query)
    {
        long long int value;           //value for which kangaroo to jump on staircase
        cin>>value;
        long long int arr[3];          // constant space for store the values
        
        arr[0]=1;
        arr[1]=1;
        arr[2]=2;
                                       //store the three values because kangaroo is jumping one, two or three steps
       if(value>2)
            {
                for(long long int i=3; i<=value;i++)
                    {
                        temp=arr[0]+arr[1]+arr[2];  // store the result of previous three step
                        arr[0]=arr[1];
                        arr[1]=arr[2];
                        arr[2]=temp;
                    }
        
                cout<<arr[2]<<"\n";    // final result for greater than 2
            }
        else if(value>0)
            {
                    cout<<arr[value]<<"\n";   // final result for 1 and 2
            }
        query--;
    }
        
    return 0;
}

