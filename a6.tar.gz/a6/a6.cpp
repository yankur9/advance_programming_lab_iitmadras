


    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   

/****************
File Name : CS18M063_HW8.cpp
Assignment:  APL-Assignment HW8
Author: Ankur Yadav(CS18M063)
Date: 22 Sep 2018
Description: File implement Kruskal's algorithm and breadth first search.
*****************/

#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
int val,m,c;   // value of no of vertices , order of matrix , no of contour

struct input // taking input of coordinate and r g b
{
    int x,y;
    int r,g,b;
};
struct dist  // distance between two point
{
    int x1,y1,x2,y2,val;
};

int find_dist(struct input **arr,int i,int j,int k,int l)// distance calculator of two vertex
{
    int x1=(arr[i][j].r-arr[k][l].r);
    int x2=(arr[i][j].g-arr[k][l].g);
    int x3=(arr[i][j].b-arr[k][l].b);
    
    return(abs(x1)+abs(x2)+abs(x3));
}

void temp_op(struct input **arr,struct dist **temp)  // distance of all neighbour node if not neighbour than -1
{
    int p=-1;
    
    for(int i=0;i<m;i++)  // checking for all 8 neighbouring position of vertex
    {
        for(int j=0;j<m;j++)
        {   p++;
            int k=0;
            
            if((i-1)>=0 &&(j-1)>=0)
            {
                temp[p][k].val=find_dist(arr,i,j,i-1,j-1);
                temp[p][k].x1=i;
                temp[p][k].y1=j;
                temp[p][k].x2=i-1;
                temp[p][k].y2=j-1;
                k++;
            }
            else
            {
                temp[p][k].val=-1;
                k++;
            }
                            if((i-1)>=0)
                            {
                                temp[p][k].val=find_dist(arr,i,j,i-1,j);
                                temp[p][k].x1=i;
                                temp[p][k].y1=j;
                                temp[p][k].x2=i-1;
                                temp[p][k].y2=j;
                                k++;
                            }
                            else
                            {
                                temp[p][k].val=-1;
                                k++;
                            }
            
            if((i-1)>=0 &&(j+1)<m)
            {
                temp[p][k].val=find_dist(arr,i,j,i-1,j+1);
                temp[p][k].x1=i;
                temp[p][k].y1=j;
                temp[p][k].x2=i-1;
                temp[p][k].y2=j+1;
                k++;
            }
            else
            {
                temp[p][k].val=-1;
                k++;
            }
                            if((j+1)<m)
                            {
                                temp[p][k].val=find_dist(arr,i,j,i,j+1);
                                temp[p][k].x1=i;
                                temp[p][k].y1=j;
                                temp[p][k].x2=i;
                                temp[p][k].y2=j+1;  
                                k++;
                            }
                            else
                            {
                                temp[p][k].val=-1;
                                k++;
                            }
            
            if((i+1)<m &&(j+1)<m)
            {
                temp[p][k].val=find_dist(arr,i,j,i+1,j+1);
                temp[p][k].x1=i;
                temp[p][k].y1=j;
                temp[p][k].x2=i+1;
                temp[p][k].y2=j+1;
                k++;
            }
            else
            {
                temp[p][k].val=-1;
                k++;
            }
            
                            if((i+1)<m)
                            {
                                temp[p][k].val=find_dist(arr,i,j,i+1,j);
                                temp[p][k].x1=i;
                                temp[p][k].y1=j;
                                temp[p][k].x2=i+1;
                                temp[p][k].y2=j;
                                k++;
                            }
                            else
                            {
                                temp[p][k].val=-1;
                                k++;
                            }
            
            if((i+1)<m &&(j-1)>=0)
            {
                temp[p][k].val=find_dist(arr,i,j,i+1,j-1);
                temp[p][k].x1=i;
                temp[p][k].y1=j;
                temp[p][k].x2=i+1;
                temp[p][k].y2=j-1;
                k++;
            }
            else
            {
                temp[p][k].val=-1;
                k++;
            }
            
                            if((j-1)>=0)
                            {
                                temp[p][k].val=find_dist(arr,i,j,i,j-1);
                                temp[p][k].x1=i;
                                temp[p][k].y1=j;
                                temp[p][k].x2=i;
                                temp[p][k].y2=j-1;
                                k++;
                            }
                            else
                            {
                                temp[p][k].val=-1;
                                k++;
                            }
         }
    }
}

struct Edge
{
    int src, dest, weight; 
};
 
struct Graph
{
    int V, E;
    struct Edge* edge;
};
 
struct Graph* createGraph(int V, int E)
{
    struct Graph* graph = new Graph;
    graph->V = V;
    graph->E = E;
 
    graph->edge = new Edge[E];
 
    return graph;
}
 
struct subset
{
    int parent;
    int rank;
};
struct subset *subsets= (new struct subset[val]);
int find(int i)
{
        if (subsets[i].parent != i)
        subsets[i].parent = find( subsets[i].parent);
 
    return subsets[i].parent;
}
void Union(int x, int y)//struct subset subsets[]
{
    int xroot = find( x);
    int yroot = find( y);

    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
 
    else
    {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}
 
int ee; // variable use for edge reduction
void print(struct Edge *result)
{
    int **dim1=new int*[val];  //    
    for(int i=0;i<val;i++) 
    {
        dim1[i]=new int[val]; 
    }
        
    for(int i=0;i<(ee-c);i++) // edge reduction
    {
        dim1[result[i].src][result[i].dest]=1;
        dim1[result[i].dest][result[i].src]=1;
    }

    int queue[val];
    int front=0,rear=0;
    queue[rear++]=0;
    
    while(front<rear)   // applying bfs on initial vertex
    {
        for(int j=0;j<val;j++)
            {
                if(dim1[queue[front]][j]==1)
                {
                    int temp=0;
                    for(int k=0;k<rear;k++)
                    {
                        if(j==queue[k])
                            temp=1;
                    }
                    if(temp==0)
                    {
                        queue[rear++]=j;
                    }
                }
            }
        front++;
    }  
    int visit[val]={0};

    for(int i=0;i<rear;i++) // make node visited with a unique value in a contour
    {
        visit[queue[i]]=1;
    }
    
    int counter=2;
    
    for(int i=0;i<val;i++)  // visit all contour using bfs in all non visited node
    {
        if(visit[i]==0)
        {
                front=0,rear=0;
                queue[rear++]=i;

                while(front<rear)
                {
                    for(int j=0;j<val;j++)
                        {
                            if(dim1[queue[front]][j]==1)
                            {
                                int temp=0;
                                for(int k=0;k<rear;k++)
                                {
                                    if(j==queue[k])
                                        temp=1;
                                }
                                if(temp==0)
                                {
                                    queue[rear++]=j;
                                }
                            }
                        }
                    front++;
                }  

                for(int ii=0;ii<rear;ii++)
                {
                    visit[queue[ii]]=counter;
                }
            counter++;
        }
        
    }
    int ccc[6]={0};
    for(int i=0;i<val;i++) // pick the vertex size of each possible contour
    {   
        ccc[visit[i]-1]++;
    }
    
    while(c>=0) // find all contour
    {
        int min=10000;
        int pos;
        for(int i=0;i<6;i++)
        {
            if(ccc[i]<min && ccc[i]!=0)// choose minimum value
            {
                min=ccc[i];
                pos=i+1; // record the position
            }
        }
        ccc[pos-1]=0;
        
        cout<<min<<" ";
        
        int size=0;
        int arr[val];
        
        for(int i=0;i<val;i++)   // find all the node of a single contour
        {
            if(visit[i]==pos)
                arr[size++]=i;
        }
        
        for(int i=0;i<size;i++) // revrset the value in coordinate
        {
            int temp=0;
            int x=arr[i]/m;
            int y=arr[i]%m;
            
            int A[8];
            
            A[0]=(x-1)*m+(y-1);
            A[1]=(x-1)*m+y;
            A[2]=(x-1)*m+(y+1);
            A[3]=x*m+(y+1);
            A[4]=(x+1)*m+(y+1);
            A[5]=(x+1)*m+y;
            A[6]=(x+1)*m+(y-1);
            A[7]=x*m+(y-1);
            
            if((x-1)>=0 && (y-1)>=0 && (x+1)<m && (y+1)<m) // used to decide whether it is middle element
            {
                for(int i=0;i<8;i++)
                {
                    if(A[i]>=0)
                    for(int j=0;j<size;j++)
                    {
                        if(A[i]==arr[j])
                        {temp++;j=size;}
                    }
                }
            }
            if(temp!=8)// print the element
            {
                cout<<"["<<x<<","<<y<<"]"<<" ";
            }
        }        
        cout<<endl;
        c--;
    }    
    
}

struct Edge  *Kruskal(struct Graph* graph) // mst algorithm
{
    int V = graph->V;
    struct Edge  *result=new struct Edge[V+100];
    int e = 0; 
    int i = 0; 
 
    for (int v = 0; v < V; ++v)
    {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }
 
    while (e < V - 1)
    {
        struct Edge next_edge = graph->edge[i++];
 
        int x = find( next_edge.src);
        int y = find( next_edge.dest);
 
        if (x != y)
        {
            result[e++] = next_edge;
            Union( x, y);
        }
    }
    ee=e; //used for edge reduction
    return(result);
}

int main() 
{
    
    cin>>val>>c;
    m=sqrt(val);
    
    struct input **arr=new struct input*[m];   // structure for input
    for(int i=0;i<m;i++)
    {
        arr[i]=new struct input[m]; 
    }
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<m;j++)  // taking input
        {
            cin>>arr[i][j].x>>arr[i][j].y;
            cin>>arr[i][j].r>>arr[i][j].g>>arr[i][j].b;
        }
    }
    
    struct dist **temp=new struct dist*[val];   // structure for distance
    for(int i=0;i<val;i++)
    {
        temp[i]=new struct dist[8]; 
    }
    
    temp_op(arr,temp);

    struct dist *queu=new struct dist[val*8];
    
    int size=0;
    for(int i=0;i<val;i++)
    {
        for(int j=0;j<8;j++)
        {
            if(temp[i][j].val!=-1) // find all non zero adjacent
            {
                queu[size].x1=temp[i][j].x1;
                queu[size].y1=temp[i][j].y1;
                queu[size].x2=temp[i][j].x2;
                queu[size].y2=temp[i][j].y2;
                queu[size].val=temp[i][j].val;
                size++;
            }
        }
    }
    
   for(int i=0;i<size-1;i++)
    {
        for(int j=0;j<size-i-1;j++) //sort them
        {
            if(queu[j].val>queu[j+1].val)
            swap(queu[j],queu[j+1]);
        }
    }
    struct Graph* graph = createGraph(val, size); // insert in a graph
 
    for(int i=0;i<size;i++)
    {
    graph->edge[i].src =  queu[i].x1*m+queu[i].y1;
    graph->edge[i].dest = queu[i].x2*m+queu[i].y2;
    graph->edge[i].weight = queu[i].val;    
    }
    struct Edge  *result=Kruskal(graph); // appply kruskal's algorithm
    print(result); //print the result
     return 0;
}
