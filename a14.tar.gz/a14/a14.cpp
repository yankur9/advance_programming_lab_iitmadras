/*****************
File Name : CS18M063_SORTING.cpp
Assignment:  APL-Assignment Lab 2
Author: Ankur Yadav(CS18M063)
Date: 07 Aug 2018
Description: File is using Radix sort & Counting sort.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

long long int n; // n is the number to be sorted

struct bignum_t // data structure for values and their sign
{
    int digit[10];
    int sign;
};

void counting_sort(int A[],int B[]) //sorting from 1,2,3...n
{
    long long int i, j,max=0;
    for(i=1;i<=n;i++)
    {
        if(A[i]>max)
            max=A[i];
    }

    int C[max];

    for(i=0;i<=max;i++)
        C[i]=0;

    for(j=1;j<=n;j++)
        C[A[j]]=C[A[j]]+1;

    for(i=1;i<=max;i++)
        C[i]=C[i]+C[i-1];

    for (j = n; j >= 1; j--)
    {
        B[C[A[j]]]=A[j];
        C[A[j]]=C[A[j]] - 1;
    }

    for(int i=0;i<n;i++) // shift the input and output array from 1 to (n-1)
    {
        A[i]=A[i+1];
        B[i]=B[i+1];        
    }
    A[n]=12;// garbage value assign
    B[n]=13;

}
void sorting(bignum_t arr[]) // sorting of number
{
    
    
    for(int i=0;i<10;i++)
    {
        
        int A[n+1],B[n+1]; // two array for input and output
        
        for(long long int j=0;j<n;j++)
        A[j+1]=(arr[j].digit[i]);  // store the digitwise number for counting sort
        
        counting_sort(A,B); // counting sort call
        
        bignum_t res[n]; //temporary tructure
        long long int j=0;
        
        for(long long int i=0;i<n;i++)
        {   
            while(B[i]!=A[j]) // search for the digit of sorted array in unsorted array
               {
                    j++;
                }
            res[i]=arr[j]; // save the corresponding value of sign and magnitude in structure
            A[j]=11; //give the garbage value
            
            if(B[i]==B[i+1]) // if digitwise number are same k will search till n
                j++;
            else 
                j=0;    // if number is diferent go for second one
        }
        for(long long int i=0;i<n;i++) // copy the temporary structure in original structure
            arr[i]=res[i];
                 
    }
}

void printing(bignum_t arr[])
{
    for(long long int i=n-1;i>=0;i--) // for print the negative number from last because highest magnitude of negative number will be smaller 
    {
        
        if(arr[i].sign==255)// check sign
        {
            
            int sum=0, m=1;
            for(int j=0;j<10;j++) //converting in to number
            {
                sum+=((arr[i].digit[j])*m);
                m*=10;
            }
           
            cout<<(sum*-1)<<" "; //magnitude multiply by -1 for negative number
        }
    }
    
    for(long long int i=0;i<n;i++)
    {
        if(arr[i].sign!=255)
        {
            
            long long int sum=0, m=1;
            for(int j=0;j<10;j++)// positive number conversion
            {
                sum+=((arr[i].digit[j])*m);
                m*=10;
            }
            cout<<sum<<" "; //positive number print
        }
        
    }
}

int main() {
    long long int i=0;
    cin>>n;   // taking no of values to be sorted
    
    bignum_t arr[n];
    
    long long int temp,j;
    
    while(i<n)
    {
        cin>>temp;
        
        j=0;
        while(temp)
            {
                (arr[i].digit[j])=temp%10; //storing digitwise values
                temp/=10;
                j++;
            }
        
        while(j<10)
            {
                (arr[i].digit[j])=0; //rest most significant bit are zero
                j++;
            }
        i++;
    }
    
    i=0;
    
    while(i<n)
    {
        cin>>temp;
        (arr[i].sign)=temp;  // storing sign of the value
        i++;
    }
    
    sorting(arr); //sorting function call
    printing(arr); //printing of final result
    
    return 0;
}

