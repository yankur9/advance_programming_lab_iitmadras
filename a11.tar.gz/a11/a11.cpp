/*****************
File Name : CS18M063_l4.cpp
Assignment:  APL-Assignment Lab 4
Author: Ankur Yadav(CS18M063)
Date: 22 Aug 2018
Description: File implement binary tree using array.
*****************/
#include <cmath>
#include <string.h>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

char A[1000];    // array for binary tree storage
int b[100];       // array for decimal to binary conversion

int  binar_y(int n)  //decimal to binary conversion
{
    int i = 0;
    while (n > 0) 
    {
        b[i] = n % 2;
        n = n / 2;
        i++;
    }
    return(i-1);
}

void inser_t()
{
    int p;
    cin>>p;   // insert node
    int l=binar_y(p); // binary conversion
    
    if(l==0) // special case for 1
    {  
        A[0]='B';
    }
    
    int i=0;
    l--; // drop one digit of binary conversion
    
    while(l>=0)
    {
        if(A[0]=='Y') // if first  node isn't declare
            A[0]='W';
        
         if(b[l]==1)        // for right node
        {
            i=(2*i)+2 ;
             if(l==0)       // for leaf node
                 A[i]='B';
             else if(A[i]!='B')
                 A[i]='W';
        }
        else if(b[l]==0)    //for left node
        {
            i=(2*i)+1;
            if(l==0)        // for leaf node
                 A[i]='B';
             else if(A[i]!='B')
                 A[i]='W';
            
        }
        l--;
    }
}
void adjust(int i)  // adjust for deletion
{
    i=(i-1)/2;  // check the parent node
    while(i>=0 && A[2*i+1]=='Y' && A[2*i+2]=='Y' && A[i]!='B')
    {
        A[i]=' ';
        i=(i-1)/2;
    }
}

void delet(int n)
{
    int l;
    l=binar_y(n);  // conversion of element that to be deleted
    int i=0;
    
    if(l==0) //for special case conversion
    {  
        if(A[0]=='B')
        {
            if(A[1]=='Y' && A[2]=='Y')
            {
                A[i]='Y';
            }
            else
                A[i]='W';
        }
        else if(A[i]=='W') // if there are descendent in the tree
        {
            if(A[1]=='Y' && A[2]=='Y')
            {
                A[i]='Y';
            }
            cout<<"Node is white"<<"\n"; 
        }
        else
            cout<<"String is not present"<<"\n";
            
    }
    
    l--;
    while(l>=0)
    {
        if(b[l]==1)  // for right node
        {
            i=(2*i)+2;
            if(l==0)
            {
                if(A[i]=='B')  
                {
                    if(A[2*i+1]=='Y' && A[2*i+2]=='Y') // if there is no child of deleted node
                    {
                        A[i]='Y';
                        adjust(i); // adjust the tree
                    }
                    else
                    A[i]='W';
                }
                else if(A[i]=='W')  // if the deleted node is not inserted
                {
                    cout<<"Node is white"<<"\n"; 
                    if(A[2*i+1]=='Y' && A[2*i+2]=='Y')
                    {
                        A[i]='Y';
                        adjust(i);  /// adjust the tree
                    }
                }
                else                // if deleted node is not present
                {
                            cout<<"String is not present"<<"\n";
                }
            }
        }
            
        else // for left node
        {
            i=(2*i)+1;
            if(l==0)
            {
                if(A[i]=='B')
                {
                    if(A[2*i+1]=='Y' && A[2*i+2]=='Y')  // if there is no child of deleted node
                    {
                        A[i]='Y';
                        adjust(i);  // adjust the tree
                    }
                    else
                        A[i]='W';
                }
                else if(A[i]=='W')   // if the deleted node is not inserted
                {
                    cout<<"Node is white"<<"\n";
                    if(A[2*i+1]=='Y' && A[2*i+2]=='Y')
                    {
                        A[i]='Y';
                        adjust(i);    // adjust the tree
                    }
                }
                else  // if deleted node is not present
                {
                    cout<<"String is not present"<<"\n";
                }
            }
        }
            
        l--;
    }
}
void convert(int i) //conversion using level traversal 
{
    int l=0;
    for(int j=i;j>0;)   //  check whether left or right using even odd concept
    {
        if(j%2==0)
        {
            b[l++]=1;
        }
        else
            b[l++]=0;
        
        j=(j-1)/2;  // go for parents
    }
    b[l]=1;
    i=0;
    int sum=0,n=1;
    while(i<=l) // convert binary to decimal
    {
        sum+=(b[i]*n);
        n*=2;
        i++;
    }
    cout<<sum<<" ";  // print decimal value
}
void prin()     // using level traversal of tree or breadth first search 
{
    int p=0;
    for(int i=0;i<1000;i++) // check for all black node of tree
    {
        if(A[i]=='B')
        {
            convert(i); // convert black node in to their corresponding value
            p++;
        }
    }
    if(p==0) // if there is no black node in tree
        cout<<"Empty Tree";
}

int main()
{
    int i;
    for(int j=0;j<1000;j++)  // makes all input yellow in the array
    A[j]='Y';
    while(1)
    {
        cin>>i;
        if(i==1)
        {
            inser_t();    // for insertion
        }
        else if(i==2)
        {
            int n;
            cin>>n;
            delet(n);    // for deletion
        }
        else if(i==3)
        {
            if(A[0]=='Y')  // if first element is yellow there is no element in array
                cout<<"Empty Tree";
            else
            {
                b[0]=1;
                prin();   // print function
            }  
            cout<<"\n";
        }
        else    // exit
        {
            return 0;
        }
    }
   return 0;
}

