/*****************
File Name : CS18M063_HackingFB.cpp
Assignment:  APL-Assignment HW 2
Author: Ankur Yadav(CS18M063)
Date: 10 Aug 2018
Description: File is using concept of simple graph and graph with multiple edges concept.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

void check2(int arr[], int n)
{
    sort(arr,arr+n);    // sort the array in increasing order
    reverse(arr,arr+n); // sort the array in decreasing order
    int j=n-1;
    while(arr[j]==0)  // remove all the zero from array
        {
            j--;
        }
    n=j+1;
    
    if(n>3)      // function repeatedly call itself for more than 3 element
        {
            arr[0]-=arr[n-1];  // substract the last element from the first element
            n--;
            check2(arr,n);
        }
    else if(n==3)  // special condition for 2
        {
            if((arr[0]+arr[1]+arr[2])%2==1)   // summation of element should not be odd
                {
                    n=1;
                    arr[0]=1;// make the result invalid
                }
            else
            {
                if(arr[0]<=(arr[1]+arr[2]))  // sum is even than and array is sorted  sum of last two element must be greater than or equal to first element
                    {
                        arr[0]=0; // make the case valid
                        n=1;
                    }
                else   // invalid case
                    {
                        arr[0]=1;
                        n=1;
                    }
            }
        }
    else if(n==2)
        {
            if(arr[0]==arr[1])  // condition for two element
            arr[0]=0;
            n=1;
        }
}

void check1(int arr[], int n)
{
    sort(arr,arr+n);  // sort the array in increasing order
    reverse(arr,arr+n); // sort the array in decreasing order

    int j=n-1;
    while(arr[j]==0 && j>=0) // remove all the zero from array
        {
            j--;
        }
    n=j+1;
    if(arr[0]>=n) // after removal of zeros first element should be less than n
    {
        cout<<"Invalid";
        return ;
    }
    for(int i=1;i<=arr[0];i++)   // substract from 1...k k=first element
        arr[i]-=1;
    
    for(int i=1;i<n;i++)     // shift the array by one
        arr[i-1]=arr[i];
        n--;   // decrease the n by one
    
    if(n>1)  // check for n greater than one
        check1(arr,n);
    else
    {
        if(arr[0]!=0)  
            cout<<"Invalid";
        else
            cout<<"Valid";
    }
}

int main() {
    int p;
    cin>>p; // input for hacking problem 1 and 2
    
    if(p==1)  // for hacking problem 1
    {
        int n,sum=0; 
        cin>>n;            // take the input for the value of n 
        int arr[n];
        for(int i=0;i<n;i++)
            {
                cin>>arr[i];  // taking input sequence
                if(arr[i]>=n || arr[i]<0)  // no element should be greater or equal to  n and less than 0
                {
                    cout<<"Invalid";
                    return 0;
                }
                sum+=arr[i];  // calculating sum of element
            }
        if(sum%2!=0) // check sum whether even or odd
            {
                cout<<"Invalid";
                return 0;
            }
        else
            {
                check1(arr,n);       // function call for part 1
            }
    }
    else if(p==2)  // for hacking problem 2
   {
       int n,sum=0;
        cin>>n;     // take the input for the value of n 
        int arr[n];
        for(int i=0;i<n;i++)    // taking input sequence
            {
                cin>>arr[i];
                if(arr[i]<0)     // no element should be less than 0
                    {
                        cout<<"Invalid";
                        return 0;
                    }
                sum+=arr[i];       // calculating sum of element
            }
        if(sum%2!=0 )               // check sum whether even or odd
            {
                cout<<"Invalid";
                return 0;
            }
        else
            {
                if(n>1)
                check2(arr,n);       // function call for part 2
         
               if(arr[0]!=0)
                cout<<"Invalid";
               else
                cout<<"Valid";
            }
   }
    return 0;
}

