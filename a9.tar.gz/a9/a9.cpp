/*****************
File Name : CS18M063_hw5.cpp
Assignment:  APL-Assignment HW 5
Author: Ankur Yadav(CS18M063)
Date: 1 sEP 2018
Description: File is using concept of Minmum heap and optimized the greedy algo.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

int h_size;                                    // heap size

struct node        // l for left side point r for right side point d is distance between them
{
    int l;
    int r;
    int d;
};

void heapify_min(struct node Arr[ ] , int i, int N) // min heapify function
{
  int left  = 2*i;
  int right = 2*i+1;
  int small;

    if(left <= N and Arr[left].d < Arr[ i ].d )
        small = left;
    else
        small = i;
    if(right <= N and Arr[right].d < Arr[small].d )
        small = right;
    if(small != i)
    {
        swap(Arr[i],Arr[small]);
        heapify_min(Arr, small,N);
    }
}

void delete_min(struct node *arr) // delete minimum element from heap
{   
   arr[1] = arr[h_size];
   --(h_size);
   heapify_min(arr,1,h_size);
}

void distance_min( struct node *heap ,int *dist,int k,int n) // distance calculator function heap is min heap , dist is array of all distances , value of k & n
{   
   int index, cost, l, r, d;
   int indices[n];     
   int val; 
    
   for (index=0; index<n; index++) indices[index] = -1;  // to check the uding points makes corresponding value less than 0
   index = 0; cost = 0;
   while (index < k) // til index not equal to value of k
   {
       val=0;// to know whether delete or not the top element of heap
      l = heap[1].l;  // store the left , right and value of distance between them
      r = heap[1].r;
      d = heap[1].d;
      if ((indices[l] < 0) && (indices[r] < 0)) // if these left and right are not mark in array 
      {
          indices[l] = indices[r] =1; // mark the left and right end points
          index++; 
          cost += d; // add the value of distance in cost
         l--; // go to one left side
         r++; // go to one right side
         if ((l >=0) && (r <n) && (indices[l] < 0) && (indices[r] < 0)) // check these l & r are within the range  and they are not mark   
         {
             d = dist[l] + dist[r-1] - d; // calculate the optimum distance between them adding outer point and substract middle point because it is already added in minmum cost
             heap[1].l=l;
             heap[1].r=r;
             heap[1].d=d;
             heapify_min(heap,1,h_size); // add it as a top node with l and r value because it cover more points in minimum distance
             val=1;// and mark that top element is deleted from heap
         } 
       }
       if(val==0) // check whether top element id=s deleted from heap
           delete_min(heap);  // delete the top element
   }
   cout<<cost;
}
int main() 
{
    int n,k;
    cin>>n>>k;                 // input tha value of n for number of points & k
    
    struct node heap[n+1];    // heap initialization
    int dist[n+1];            // store the distance of all points
    h_size=n-1;               //size of heap
    
    for(int i=1;i<n;i++)
    {
        cin>>heap[i].l>>heap[i].r>>heap[i].d;  // input element in heap
        heap[i].l-=1;   // storing the values from zero that's why -1
        heap[i].r-=1;
        dist[i-1]=heap[i].d; // storing the distance
    }
    
    for( int i = n/2 ; i >0 ; i--)   // make the min heap
    heapify_min(heap, i,h_size);
    
    distance_min(heap,dist,k,n);  //minimum distance calculator function
    
    return 0;
}
