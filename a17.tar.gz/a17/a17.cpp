#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
string res[10000];
int t=0,n,red,blue; 
/*
red & blue are number of red and blue balls 
t is the number of final array
n is summation of red and blue balls
res is string of array to store final result
*/


void sort_print()  // print the final result
{
    sort (res, res + t);
    
    for(int i = 0; i < t; i++)
        {
            cout << res[i] << "\n";
        }
    
    cout<<t<<"\n";
}
void arrange1(char arr[], int i, int r,int b)  // to get total possible combination of case 1
{
     i++;
    
    if( arr[i-1]=='R' && i<n && b>0  )
        {
            arr[i]='B';
            arrange1(arr,i,r,b-1);
        }
    
    else if(arr[i-1]=='B' && i<n && ( r>0 || b>0) )
        {
            if(r>0)
                {
                    arr[i]='R';
                    arrange1(arr,i,r-1,b);
                }
            if(b>0)
                {
                    arr[i]='B';
                    arrange1(arr,i,r,b-1);
                }
        }
    if(i==n && r==0 && b==0)
        {
            arr[i]='\0';
            res[t]=arr;
            t++;
        }
}
void sort1() // sorting for case 1
    {
        char arr[n];
        t=0;
        int i=0, r=red, b=blue;
    
        arr[i]='B';
        arrange1(arr,i,r,b-1);
        arr[i]='R';
        arrange1(arr,i,r-1,b);
    }
void arrange2(char arr[], int i, int r,int b) // to get total possible combination of case 2
{
     i++;
    
    if(i>1)
        {
            if((arr[i-1]=='B' || (arr[i-1]=='R' &&  arr[i-2]=='B')) && i<n && (r>0 || b>0))
                {
                    if(r>0)
                        {
                            arr[i]='R';
                            arrange2(arr,i,r-1,b);
                        }
                    if(b>0)
                        {
                            arr[i]='B';
                            arrange2(arr,i,r,b-1);
                        }  
                }
        
            else if(arr[i-1]=='R' &&  arr[i-2]=='R' && i<n && b>0)
                {
                    arr[i]='B';
                    arrange2(arr,i,r,b-1);
                }
        }
     else if( i<n && ( r>0 || b>0) )
           {
                if(r>0)
                    {
                        arr[i]='R';
                        arrange2(arr,i,r-1,b);
                    }
                if(b>0)
                    {
                        arr[i]='B';
                        arrange2(arr,i,r,b-1);
                    } 
           }
    
    if(i==n && r==0 && b==0)
        {
            arr[i]='\0';
            res[t]=arr;
            t++;
        }
}


void sort2() // sorting of case 2
    {
        char arr[n];
        t=0;
        int i=0, r=red, b=blue;
    
        arr[i]='B';
        arrange2(arr,i,r,b-1);
        arr[i]='R';
        arrange2(arr,i,r-1,b);
}

int main() {
    int q;      // q for total number of query to be executed
    cin>>q;
    while(q>0)
        {
            cin>>red>>blue;
            n=red+blue;
        
            sort1();
            sort_print();
            sort2();
            sort_print();
            q--;
        }
}
