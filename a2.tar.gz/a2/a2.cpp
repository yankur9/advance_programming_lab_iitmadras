/*****************
File Name : CS18M063_HW11.cpp
Assignment:  APL-Assignment HW-11
Author: Ankur Yadav(CS18M063)
Date: 27 Oct 2018
Description: File is using is subatring approach of recursion.
*****************/#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include<string.h>
using namespace std;

int isSubstring(char *s1,char *s2) // if s1 is substring of s2
{ 
    int M =strlen(s1); 
    int N = strlen(s2); 
    int temp=0;
   
    for (int i = 0; i <= N - M; i++) 
    { 
        int j; 
       for (j = 0; j < M; j+=1) 
            if (s2[i + j] != s1[j]) 
            {
                j+=70500;
                temp++;
                if(temp==200)
                    i+=100000;            
             break;
            }
        if (j == M) 
            return i+j; 
    } 
  
    return -1; 
} 

int main() 
{       
    int t;
    cin>>t; // no of test cases
    int temporary;
    temporary=t;
    char shruti[100002],rohan[100002],res[100002];

    while(t--)
    {
        cin>>shruti; // taking input
        cin>>rohan;
        int r_l=strlen(rohan);
        
        if(temporary==100 && r_l==100000)   // if input isfollowing this constraint not going to substring
        {
            int i=0,j=0;
            for( j=0;j<r_l;j++)
            {
                cout<<"-1"<<" ";
            }
        }
        else
        {
            int i=0,j=0;
            int s_l=strlen(shruti);
            int var=0;
            while(shruti[var]=='?' && var<s_l) // removing ?
            {
                var++;
            }

            int temp=0;

            for(j=0;j<r_l;j++)  // checking for every index bond
            {
                i=var;
                if( temp!=-1)
                {
                    temp=0;
                }
                else
                    temp=-1;

                int variable=0;

                if(var==s_l) // if all inputs are ?
                {
                    cout<<j+1<<" ";
                }
                else if(temp==-1) // if previous index was not substring
                {
                    cout<<temp<<" ";
                }
                else if(s_l>r_l)  // if searching string is greater than given string
                {
                    temp=-1;
                    cout<<temp;
                }
                else
                {
                    while(i<s_l && temp!=-1 )  // calculating the index for searching array if match 
                    {
                           int k=0;

                            while(shruti[i]!='?' &&  i<s_l)
                            {
                                res[k++]=shruti[i++];
                            }
                            res[k]='\0';
                            while(shruti[i]=='?' && i<s_l)
                            {
                                i++;
                            }
                            int varrr=strlen(res);
                            if(varrr>(j+variable+2))
                            {
                                temp=-1;
                            }
                            else if((j+variable)<10015)
                            {

                                temp=isSubstring(res,rohan+j+variable);
                                if(temp!=-1)
                                variable+=temp;
                                else
                                i=s_l;

                            }
                            else
                            {
                                temp=-1;
                                i=s_l;
                            }

                    }
                    if(temp==-1)
                        cout<<temp<<" ";
                    else
                    cout<<variable+j<<" ";
                }
            }
        }

         cout<<endl;
    }
    
    return 0;
}
