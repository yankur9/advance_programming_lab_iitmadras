/*****************
File Name : CS18M063_HW9.cpp
Assignment:  APL-Assignment HW 9
Author: Ankur Yadav(CS18M063)
Date: 13 Oct 2018
Description: File is using linear search and binary algo to select the frequency of subsequence.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include<string.h>
using namespace std;

void fun(char *T,char *t , int freq)  // increase the frequency of subsequence
{
    int l=strlen(T);
    int j=0,temp=0;
    
    for(int i=0;i<l;i++)
    {
        temp=0;
        while((temp++)<freq)
        {
            t[j++]=T[i];
        }
    }
    t[j]='\0';
}

int compare(char *s,char *t)  // check whether subsequence present or not
{
    int l1=strlen(s), l2=strlen(t);
    int i=0,j=0;
    
    for(;i<l1 && j<l2;i++)
    {
        if(t[j]==s[i])
        {
            j++;
        }
    }
    if(j==l2)
        return 1;
    else 
        return 0;
    
}

int success;  // store the frequency which is successful

void binary(char *s,char *t,char *T, int l, int r) // binary call
{ 
    int temp;
   if (l<=r) 
   { 
        int mid = l + (r - l)/2; 
 

            fun(T,t,mid);
            temp=compare(s,t);
    
       if (temp==1)
        {   
            success=mid; // store the successful frequency
             binary(s,t,T, mid+1,r); 
        }
        else
            binary(s,t,T, l,mid-1); 
   } 
   
} 
int main() 
{
    char s[105],t[105],T[105];
    cin>>s>>T;  // input string and subsequence
    
        fun(T,t,1);  // check for input subsequence with frequency 1
        int temp=compare(s,t);
        if(temp==0)
        {
            cout<<"0";
            exit(0);
        }
    
        int limit=strlen(s)/strlen(T);  // maximum possible frequency
    
        fun(T,t,limit);  // // check for input subsequence with frequency maximum
        temp=compare(s,t);
        if(temp==1)
        {
            cout<<limit;
            exit(0);
        }
        binary(s,t,T, 1, limit);  // binary function 
        cout<<success;
    
    return 0;
}
