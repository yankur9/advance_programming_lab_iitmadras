/*****************
File Name : CS18M063_JumpingKangaroowithmcoin.cpp
Assignment:  Advance Programming Lab HW - 1 
Author: Ankur Yadav(CS18M063)
Date: 04 Aug 2018
Description: File implement dynamic programming. in this we take the summation of previous three element of previous row.
*****************/

#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;



int main() 
{
     long long  query;  // number of query
    cin>>query;
    
    while(query)
    {
        long long  n,m;
        cin>>n>>m;                            // take the value of N and M , To find C(N,M)
        
        long long  arr[n+1];                  // array of n+1 element
        
                                              // assign the value available in row 1(coin 1)
        arr[0]=0;
        arr[1]=1;
        arr[2]=1;
        arr[3]=1;
 
        for(long long  i=4;i<=n;i++)           // rest value are zero in row 1
        {
            arr[i]=0;
        }
        
       
        
        
        if(m>=2)                                // for Row 2 (coin2)
                { 
                    for(long long i=n;i>2;i--)  // due to overlapping problem loop start from the end
                        {
                            arr[i]=arr[i-1]+arr[i-2]+arr[i-3];  // add the previous three value
                        }
                    arr[2]=1;
                    arr[1]=0;
                    
                    
                }
        
        
         
        for(long long  i=3;i<=m;i++)           // row for rest of the coin ,each coin have a new row
        {
            
                    for(long long  j=n;j>=i;j--)
                        {
                            arr[j]=arr[j-1]+arr[j-2]+arr[j-3];
                        }
            
                    for(long long  j=0;j<i;j++)
                        {
                            arr[j]=0;
                        }
                 
        }
        
       cout<<arr[n]<<"\n";                      // final result of each query
        
        query--;
    }
    return 0;
}
