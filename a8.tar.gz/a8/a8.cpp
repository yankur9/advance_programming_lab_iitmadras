/*****************
File Name : CS18M063_HW6.cpp
Assignment:  APL-Assignment HW 6
Author: Ankur Yadav(CS18M063)
Date: 08 Sep 2018
Description: File is using Breadth First Search.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

int m,n; // size of input array mxn

struct node
{
    int a_i;  // position of x
    int a_j;  //  position of y
    int a_mod; // in which mode it is :        0 for cycling       1 for driving
    int a_move; // number of move it take
};
struct input
{
int val;          // value input normal, grey or black
int pos=0;  // to check the cycle or driving
};

struct node queu[20000];  // to implement the breadth first search
int front,rear;  // first to delete from queue rear for insertion

void insert(int i ,int j, int mod , int move) // inserting the node in queue
{
    queu[rear].a_i=i;
    queu[rear].a_j=j;
    queu[rear].a_mod=mod;
    queu[rear].a_move=move;
    rear++;
}

void min_move(struct input *arr[],int i,int j,int mod,int move) // function to calculate the minimum move
{
     
if(mod==0) // cycling mode
    {
        if((i-2)>=0 && arr[i-1][j].val!=0 && arr[i-2][j].val!=0 && (arr[i-2][j].pos!=5)&&(arr[i-2][j].pos!=2))
        {// left visit
            arr[i-2][j].pos+=2;
            if((arr[i-2][j].val)==2) // node is grey
                insert(i-2,j,1,move+1);
            else
                insert(i-2,j,0,move+1);
        }
    
        if((i+2)<m && arr[i+1][j].val!=0 && arr[i+2][j].val!=0 && (arr[i+2][j].pos!=5)&&(arr[i+2][j].pos!=2))
        {// right visit
            arr[i+2][j].pos+=2;
            if((arr[i+2][j].val)==2)// check for grey
                insert(i+2,j,1,move+1);
            else
                insert(i+2,j,0,move+1);
        }
    
        if((j-2)>=0 && arr[i][j-1].val!=0 && arr[i][j-2].val!=0 && (arr[i][j-2].pos!=5)&&(arr[i][j-2].pos!=2))
        {// down visit
            arr[i][j-2].pos+=2;
            if((arr[i][j-2].val)==2)// check for grey
                insert(i,j-2,1,move+1);
            else
                insert(i,j-2,0,move+1);
        }
    
        if((j+2)<n && arr[i][j+1].val!=0 && arr[i][j+2].val!=0 && (arr[i][j+2].pos!=5)&&(arr[i][j+2].pos!=2))
        {// up visit
            arr[i][j+2].pos+=2;
            if((arr[i][j+2].val)==2) // check for grey
                insert(i,j+2,1,move+1);
            else
                insert(i,j+2,0,move+1);
        }
        
    }
    else if(mod==1) // driving mode
    {
        if((i-3)>=0 && arr[i-1][j].val!=0 && arr[i-2][j].val!=0 && arr[i-3][j].val!=0&& (arr[i-3][j].pos!=5)&&(arr[i-3][j].pos!=3))
        {// left visit
            arr[i-3][j].pos+=3;
            if((arr[i-3][j].val)==2)// check for grey
                insert(i-3,j,0,move+1);
            else
                insert(i-3,j,1,move+1);
        }
        
        if((i+3)<m && arr[i+1][j].val!=0 && arr[i+2][j].val!=0&& arr[i+3][j].val!=0 && (arr[i+3][j].pos!=5)&&(arr[i+3][j].pos!=3))
        {// right visit
            arr[i+3][j].pos+=3;
            if((arr[i+3][j].val)==2)// check for grey
                insert(i+3,j,0,move+1);
            else
                insert(i+3,j,1,move+1);
        }
        
        if((j-3)>=0 && arr[i][j-1].val!=0 && arr[i][j-2].val!=0&& arr[i][j-3].val!=0 && (arr[i][j-3].pos!=5)&&(arr[i][j-3].pos!=3))
        {// down visit
            arr[i][j-3].pos+=3;
            if((arr[i][j-3].val)==2)  // check for grey
                insert(i,j-3,0,move+1);
            else
                insert(i,j-3,1,move+1);  
        }
        
        if((j+3)<n && arr[i][j+1].val!=0 && arr[i][j+2].val!=0&& arr[i][j+3].val!=0 && (arr[i][j+3].pos!=5)&&(arr[i][j+3].pos!=3))
        {// up visit
            arr[i][j+3].pos+=3;
            if((arr[i][j+3].val)==2) // check for grey
                insert(i,j+3,0,move+1);
            else
                insert(i,j+3,1,move+1);
        }
    }
}


int main() 
{
    int k;  // number of test cases
    int dest_x,dest_y;      // the destination point
    
    cin>>k;
    
    while(k--)
    {
        cin>>m>>n;
        
        struct input **arr=new struct input*[m];   // structure for input
        for(int i=0;i<m;i++)
        {
            arr[i]=new struct input[n]; 
        }
        
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                cin>>arr[i][j].val; // taking input of array
            }
        }
        cin>>dest_x>>dest_y;  // destination point
        
        if((arr[dest_x][dest_y].val==0 || arr[0][0].val==0)) // if initial or destination node is black
        {
            cout<<"-1"<<endl;
            continue;
        }
        if(dest_x==0 && dest_y==0 ) // if destination is starting node
        {
            cout<<"0"<<endl;
            continue;
        }
        if((dest_x>=m || dest_y>=n)) // if destination is out of bound
        {
            cout<<"-1"<<endl;
            continue;
        }
        
        front=0;
        rear=0;
      // inserting first node in queue
        queu[rear].a_i=0;
        queu[rear].a_j=0;
        queu[rear].a_mod=arr[0][0].val-1;
        queu[rear].a_move=0;
        rear++;
        arr[0][0].pos+=2;
                
        for( ;(front<=rear) ;front++) // visit in queue
        {
            
            if(front==rear) // destination is not rachable
            {
                cout<<"-1"<<endl;
                break;
            }
            if(queu[front].a_i==dest_x && queu[front].a_j==dest_y ) // reach the destination
            {
                cout<<queu[front].a_move<<endl;
                break;
            }
            
            min_move(arr,queu[front].a_i , queu[front].a_j , queu[front].a_mod , queu[front].a_move); // apply bfs
        }
        free(arr);
    }
    
    return 0;
}
