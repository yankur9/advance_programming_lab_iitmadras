#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include<string.h>
using namespace std;


int main() 
{
    char arr[10000009];
    int t;
    
    cin>>t;
    cin>>arr;
    
    int c=1;
    
    while(c)
    {
        c=0;
        int l=strlen(arr);
        //cout<<l;
        int i;
        for( i=0;i<l-1;i++)
        {
            
            if(arr[i]==arr[i+1])
            {
                arr[i]='*';
                arr[i+1]='*';
                    i=i+2;
                c=1;
            }
        }
        //cout<<arr<<endl;
        
        //if(arr[i]==arr[i+1])
          //  {
                //c=1;
                int j,p;
                for( j=0,p=0;j<l;j++)
                {
                    if(arr[j]!='*')
                    {
                    arr[p]=arr[j];
                        p++;
                    }
                }
                arr[p]='\0';
        //cout<<arr<<endl;
           // }
        
    }
    cout<<strlen(arr);
    return 0;
}

