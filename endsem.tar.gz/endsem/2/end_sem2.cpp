#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include<string.h>
using namespace std;


int main()
{
    
    int t;
    cin>>t;
    while(t--)
    {
       char arr[10000];
        char a[10000];
       cin>>arr;
       int l=strlen(arr);
    
        
        for(int p=0;p<l;p++)
        {
            int x;
            x=arr[p];
            
            if(x<97 )
            {
                arr[p]=x+32;
            }
            a[l-p-1]=arr[p];
        }
 
        a[l]='\0';
        
        int **var=new int*[l+1];
        for(int i=0;i<=l;i++)
        {
            var[i]=new int[l+1];
        }
        
        for(int i=0;i<=l;i++)
        {
            var[i][0]=0;
            var[0][i]=0;
        }
        
        for(int i=1;i<=l;i++)
        {
            for(int j=1;j<=l;j++)
            {
                if(arr[i-1]==a[j-1])
                {
                    var[i][j]=var[i-1][j-1]+1;
                }
                else
                {
                    if(var[i][j-1]>var[i-1][j])
                    {
                        var[i][j]=var[i][j-1];
                    }
                    else
                    {
                        var[i][j]=var[i-1][j];
                    }
                }
            }
        }
        
        cout<<var[l][l]<<endl;
        
    }
    
    
    return 0;
}

