/*****************
File Name : CS18M063_l3.cpp
Assignment:  Advance Programming Lab HW - 1 
Author: Ankur Yadav(CS18M063)
Date: 18 Aug 2018
Description: File implement divide and conquer approach and Karastuba algorithm.
*****************/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;

int* karastuba(int A[],int B[],int size)
{
    if(size==1)                             // condition for input size 1
        {
            int *C=new int[2*size];
            C[1]=A[0]*B[0];
            C[0]=1;                         // first element store the size of array
            return(C);
        }
    int a,b;
    a=(int)ceil(((double)size)/2.0);        // division of array
    b=size-a;
    
    int *d0=karastuba(A,B,a);               // first funtion call for lower partition
    int *d1=karastuba(A+a,B+a,b);           // second partition for upper partition
    int temp1[a],temp2[a];                  // two temporary array for third function call
    
    for(int i=0;i<a;i++)                    // adjust the element in A lower and A upper , B lower and B upper
        {
            if(i<b)
                {
                    temp1[i]=A[i]+(A+a)[i];
                    temp2[i]=B[i]+(B+a)[i];
                }
            else
                {
                    temp1[i]=A[i];
                    temp2[i]=B[i];
                }
        }
    
    int *d01=karastuba(temp1,temp2,a);      // third fuction call
    int i,j,k;                              // first element of array return by three function  
    i=d0[0];
    j=d1[0];
    k=d01[0];
    
    for(int a1=1,a2=1,a3=1;a3<=k;a1++,a2++,a3++)   // substract d01-(d0+d1)
        {
            if(a1<=i && a2<=j)
                {
                    d01[a3]=d01[a3]-(d0[a1]+d1[a2]);
                }
            else if(a1<=i && a2>j)
                {
                    d01[a3]=d01[a3]-d0[a1];
                }
            else if(a>i && a2<=j)
                {
                    d01[a3]=d01[a3]-d1[a2];
                }
        }
    
    int *final=new int[2*size];                  // temp array for final result
    int shift=(int)ceil(((double)size)/2.0)-1;   // get number of element to be shifted 
    int x,y,z;
                                                 //shift the element and merge the array in to a single one
    for( x=1;x<=(i-shift);x++)
        final[x]=d0[x];
    for(y=1;y<=shift;x++,y++)
        final[x]=d0[x]+d01[y];
    for(;y<=(k-shift);x++,y++)
        final[x]=d01[y];
    for(z=1;z<=shift;x++,y++,z++)
        final[x]=d1[z]+d01[y];
    for(;z<=j;x++,z++)
        final[x]=d1[z];
    
    //free(d0);
    //free(d1);
    //free(d01);
    
    final[0]=x-1;                                // store the size of result in array
    return(final);                               // return the final array
}

int main() {
   int m,n;                                      //size of both array
    cin>>m>>n;
    
    int max=((m>n)?m:n);                         // determine which one is max in m and n
    
    int A[max],B[max];                           // declaration of both array
    
    for(int i=0;i<m;i++)
    cin>>A[i];                                   // input array 1
    
    for(int i=0;i<n;i++)
    cin>>B[i];                                   // input array 2
     
    if(m==max)                                   // making both array equal
        for(int i=n;i<max;i++)
            B[i]=0;
    else
        for(int i=m;i<max;i++)
            A[i]=0;
    
    int *C=karastuba(A,B,max);                   // calling of function
    
    max=C[0];                                    // first element store size of array
    while(C[max]==0)                             // remove all 0's in last
    {
        max--;
    }
    
    for(int i=1;i<=max;i++)                      // print the result 
        cout<<C[i]<<" ";
    
    return 0;
}
